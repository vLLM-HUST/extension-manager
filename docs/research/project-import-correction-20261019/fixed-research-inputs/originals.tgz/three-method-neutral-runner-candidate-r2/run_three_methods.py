"""Root-executed future H2 research block. Never launched by source preparation."""
import argparse
import errno
import fcntl
import hashlib
import http.client
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import stat
import subprocess
import threading
import time

from ownership import capture, current, ident, npu, send

HERE = Path(__file__).resolve().parent
ROLES = {'manager', 'host', 'ascend', 'kv', 'profiler'}
KV = 'ascend_kvcompress'
PROF = 'request_lifecycle_profiler'
IDS = {KV: 'org.vllm-hust.ascend-kvcompress', PROF: 'org.vllm-hust.request-lifecycle-profiler'}
CASES = [('host-only', []), ('kv-only', [KV]), ('profiler-only', [PROF]),
         ('kv-then-profiler', [KV, PROF]), ('profiler-then-kv', [PROF, KV])]
PROMPTS = [('below', 'Name a color.', 4), ('above', 'Evidence-bound compression transaction sentence. ' * 200, 1201)]
RESET = ('ECPA_', 'VLLM_ECPA_', 'VLLM_HUST_EXT_', 'VLLMHUST_', 'VLLM_ASCEND_KVCOMPRESS_', 'VLLM_RLP_')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def save(path, value):
    path.write_bytes(canonical(value) + b'\n')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def checked(ref):
    path = Path(ref['path'])
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != ref['sha256'].removeprefix('sha256:'):
        raise ValueError('input reference SHA differs: ' + str(path))
    return raw


def private_directory(path):
    path.mkdir(mode=0o700, parents=False, exist_ok=False)
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if before.st_uid != os.geteuid():
            raise ValueError('private directory owner mismatch')
        os.fchmod(fd, 0o700)  # Explicitly clear inherited SGID before descendants.
        after = os.fstat(fd)
        actual = path.lstat()
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino) or (after.st_dev, after.st_ino) != (actual.st_dev, actual.st_ino) or stat.S_IMODE(after.st_mode) != 0o700:
            raise ValueError('private directory inode/mode changed')
    finally:
        os.close(fd)


def clock_pair():
    return dict(monotonic_before_ns=time.monotonic_ns(),
                raw_ns=time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW),
                monotonic_after_ns=time.monotonic_ns(), wall_ns=time.time_ns())


def load_inputs(path):
    raw = path.read_bytes()
    data = json.loads(raw)
    if data['schema'] != 'ecpa-H2-three-method-runtime-inputs/v1' or set(data['sources']) != ROLES or set(data['source_proofs']) != ROLES:
        raise ValueError('explicit exact five-source runtime inputs required')
    for value in data['sources'].values():
        if len(value) != 40 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('full source commit required')
    for ref in [data['installed_wheel_proof'], data['kv_config'], data['token_inputs'], data['oracle_rule'], *data['source_proofs'].values()]:
        checked(ref)
    python = Path(data['python'])  # Preserve actual virtualenv lexical prefix.
    if not python.is_absolute() or not python.is_file():
        raise ValueError('absolute selected runtime Python missing')
    proof = json.loads(checked(data['installed_wheel_proof']))
    def strings(value):
        if isinstance(value, str):
            yield value
        elif isinstance(value, dict):
            for child in value.values():
                yield from strings(child)
        elif isinstance(value, list):
            for child in value:
                yield from strings(child)
    prefix = str(python.parent.parent)
    if not any(value == prefix or value.startswith(prefix + '/') for value in strings(proof)):
        raise ValueError('installed-wheel proof does not bind selected actual runtime prefix')
    kv = json.loads(checked(data['kv_config']))
    if set(kv) != {'schema_version', 'provider', 'method', 'method_config'} or kv['provider'] != KV:
        raise ValueError('actual direct-provider intent required')
    for key, value in {'kv_budget': 1024, 'recompute_window': 128, 'min_output_tokens_for_compression': 16}.items():
        if kv['method_config'].get(key) != value:
            raise ValueError('original KV intent differs')
    return data, kv, hashlib.sha256(raw).hexdigest()


def environment(data, out, selected, method, order_mode, kv_path, manager_path):
    # No ECPA resolved child environment is copied into a baseline.
    env = {k: v for k, v in data['environment'].items() if not k.startswith(RESET)}
    for key in ('PATH', 'LD_LIBRARY_PATH', 'ASCEND_HOME_PATH', 'ASCEND_TOOLKIT_HOME', 'ASCEND_OPP_PATH', 'ASCEND_AICPU_PATH'):
        if key in os.environ:
            env[key] = os.environ[key]
    env.update(PYTHONPATH=str(HERE) + ':/usr/local/Ascend/cann-9.1.0/python/site-packages:/usr/local/Ascend/cann-9.1.0/opp/built-in/op_impl/ai_core/tbe',
               PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               ASCEND_RT_VISIBLE_DEVICES='0,1', VLLM_PLUGINS=','.join(['ascend', *selected]),
               ECPA_H2_RAW=str(out), ECPA_H2_ORDER=json.dumps(selected), ECPA_H2_ORDER_MODE=order_mode,
               ECPA_NEUTRAL_NPU_DIRECTORY=str(out / 'neutral'), ECPA_NEUTRAL_NPU_NONCE=secrets.token_hex(32),
               OMP_NUM_THREADS='1', VLLM_WORKER_MULTIPROC_METHOD='spawn', VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS='12',
               TRITON_CACHE_DIR=str(out / 'triton-cache'), XDG_CACHE_HOME=str(out / 'cache'))
    if KV in selected and method != 'ecpa':
        env.update(VLLM_ASCEND_KVCOMPRESS_ENABLED='1', VLLM_ASCEND_KVCOMPRESS_CONFIG=str(kv_path))
    if method == 'ecpa':
        env['VLLM_HUST_EXT_CONFIG'] = str(manager_path)
    if PROF in selected:
        env.update(VLLM_RLP_TRACE_EXPORT_PATH=str(out / 'profiler.jsonl'), VLLM_RLP_COMMUNICATION_MODE='none',
                   VLLM_RLP_PROFILER_PARENT_COMMIT=data['sources']['profiler'],
                   VLLM_RLP_RUNTIME_CORE_COMMIT=data['sources']['host'], VLLM_RLP_DEVICE_PLUGIN_COMMIT=data['sources']['ascend'])
    return env


def command(python, selected, method, port):
    module = 'vllm_request_lifecycle_profiler.launcher' if method == 'native' and PROF in selected else 'vllm.entrypoints.cli.main'
    host = [str(python), '-m', module, 'serve', '/models/Qwen2.5-7B-Instruct', '--served-model-name', 'ecpa-h2-real',
            '--host', '127.0.0.1', '--port', str(port), '--shutdown-timeout', '5', '--tensor-parallel-size', '2', '--enforce-eager',
            '--max-model-len', '2048', '--max-num-seqs', '1', '--gpu-memory-utilization', '0.6', '--block-size', '128',
            '--no-enable-prefix-caching', '--enable-chunked-prefill']
    return [str(python.parent / 'vllm-hust-ext'), 'run', '--', *host] if method == 'ecpa' else host


def exchange(port, raw, rid, out, kind):
    """One original request, absolute240 seconds, partial bytes/errors retained."""
    started = time.monotonic_ns()
    deadline = started + 240_000_000_000
    connection = http.client.HTTPConnection('127.0.0.1', port, timeout=240)
    stop = threading.Event()
    rows = dict(rid=rid, start=clock_pair(), deadline_monotonic_ns=deadline, timeout_s=240)
    body = bytearray()
    watchdog = None
    try:
        connection.connect()
        owned_socket = connection.sock
        def expire():
            if not stop.wait(max(0, (deadline - time.monotonic_ns()) / 1e9)):
                rows['local_deadline_shutdown'] = clock_pair()
                try:
                    owned_socket.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
        watchdog = threading.Thread(target=expire, daemon=True)
        watchdog.start()
        connection.request('POST', '/v1/completions', body=raw,
                           headers={'Content-Type': 'application/json', 'X-Request-Id': rid})
        rows['backend_sent'] = clock_pair()
        response = connection.getresponse()
        rows.update(http_status=response.status, headers=response.getheaders())
        while True:
            chunk = response.read(65536)
            if not chunk:
                break
            body.extend(chunk)
        rows['received'] = clock_pair()
        if 'local_deadline_shutdown' in rows or time.monotonic_ns() > deadline:
            raise TimeoutError('original absolute240s HTTP deadline')
        if response.status != 200:
            raise RuntimeError('HTTP status ' + str(response.status))
        value = json.loads(body)
        if value.get('model') != 'ecpa-h2-real' or not value.get('choices') or not value['choices'][0].get('text'):
            raise ValueError('actual functional response differs')
        rows['usage'] = value.get('usage')
        rows['response_id'] = value.get('id')
    except BaseException as error:
        rows['error'] = repr(error)
        raise
    finally:
        stop.set()
        connection.close()
        if watchdog is not None:
            watchdog.join(timeout=2)
            if watchdog.is_alive():
                rows['watchdog_cleanup_failed'] = True
        rows['terminal'] = clock_pair()
        (out / f'{kind}-response.json').write_bytes(body)
        save(out / f'{kind}-response-clock.json', rows)
    return rows


def port_is_closed(port):
    """A released listener may retain TCP TIME_WAIT; bind is not the predicate."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(2)
        return sock.connect_ex(('127.0.0.1', port)) == errno.ECONNREFUSED


def execute(root, name, selected, data, kv, method, repeat, mode, port):
    out = root / name
    private_directory(out)
    private_directory(out / 'neutral')
    npu(out / 'npu-before.txt')
    save(out / 'kv-provider-intent.json', kv)
    config = {'schema_version': 2, 'extensions': {IDS[x]: {'enabled': True, **({'configuration': kv} if x == KV else {})} for x in selected}}
    save(out / 'manager-config.json', config)
    env = environment(data, out, selected, method, mode, out / 'kv-provider-intent.json', out / 'manager-config.json')
    argv = command(Path(data['python']), selected, method, port)
    result = dict(schema='ecpa-H2-three-method-neutral-attempt/v1', method=method, repeat_index=repeat, case=name,
                  requested_order=selected, order_mode=mode, actual_order=None, error=None, formal_qualified=False,
                  performance_result=False, start=clock_pair(), argv=argv, source_commits=data['sources'],
                  campaign_sha256=digest(root / 'campaign.json'), actual_environment_sha256=hashlib.sha256(canonical(env)).hexdigest(), study_trace_nonce=env['ECPA_NEUTRAL_NPU_NONCE'])
    save(out / 'attempt.json', result)
    save(out / 'declared-environment.json', {k: v for k, v in env.items() if k.startswith(RESET) or k in ('PYTHONPATH', 'VLLM_PLUGINS', 'ASCEND_RT_VISIBLE_DEVICES', 'VLLM_WORKER_MULTIPROC_METHOD', 'VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS', 'OMP_NUM_THREADS')})
    seen = {}
    process = None
    try:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', port))
        with (out / 'stdout.log').open('wb') as stdout, (out / 'stderr.log').open('wb') as stderr:
            process = subprocess.Popen(argv, env=env, cwd=out, stdout=stdout, stderr=stderr,
                                       stdin=subprocess.DEVNULL, start_new_session=True)
            result['owner'] = ident(process.pid)
            save(out / 'Popen.json', result['owner'])
            deadline = time.monotonic() + 720
            while time.monotonic() < deadline:
                capture(process.pid, seen)
                if process.poll() is not None:
                    raise RuntimeError(f'product exited before health: {process.returncode}')
                connection = http.client.HTTPConnection('127.0.0.1', port, timeout=2)
                try:
                    connection.request('GET', '/health')
                    response = connection.getresponse()
                    if response.status == 200:
                        result['health_status'] = 200
                        result['health_observed'] = clock_pair()
                        break
                except OSError:
                    pass
                finally:
                    connection.close()
                time.sleep(1)
            else:
                raise TimeoutError('health deadline720s')
            for kind, prompt, expected_tokens in PROMPTS:
                request = dict(model='ecpa-h2-real', prompt=prompt, max_tokens=32, temperature=0, seed=20261019, ignore_eos=True)
                save(out / f'{kind}-request.json', request)
                rid = f'h2-{method}-r{repeat}-{name}-{kind}'
                row = exchange(port, json.dumps(request).encode(), rid, out, kind)
                result[kind] = row
                if not row['usage'] or row['usage'].get('prompt_tokens') != expected_tokens or row['usage'].get('completion_tokens') != 32:
                    raise ValueError('actual HTTP token usage differs from original4/1201+32')
                capture(process.pid, seen)
                save(out / 'attempt.json', result)
            time.sleep(2)
    except BaseException as error:
        result['error'] = repr(error)
    finally:
        if process is not None:
            capture(process.pid, seen)
            if process.poll() is None and 'owner' in result:
                send(result['owner'], signal.SIGINT)
                try:
                    process.wait(timeout=25)
                except subprocess.TimeoutExpired:
                    pass
            for sig in (signal.SIGTERM, signal.SIGKILL):
                for item in reversed(list(seen.values())):
                    send(item, sig)
                time.sleep(2)
            try:
                result['returncode'] = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                result['returncode'] = None
        result.update(retained_processes=list(seen.values()), owned_survivors=[item for item in seen.values() if current(item)], finished=clock_pair())
        try:
            npu(out / 'npu-after.txt')
            result['device_process_tables_empty'] = True
        except Exception as error:
            result.update(device_process_tables_empty=False, cleanup_error=repr(error))
        result['port_closed'] = port_is_closed(port)
        save(out / 'attempt.json', result)
        save(out / 'raw-files.json', {str(q.relative_to(out)): digest(q) for q in out.rglob('*')
                                     if q.is_file() and q.name != 'raw-files.json' and not any('cache' in part for part in q.relative_to(out).parts)})
    return result


def freeze_inputs(root, args, data, kv, input_sha):
    """Freeze actual inputs before first product Popen, not a pass verdict."""
    frozen = root / 'frozen'
    private_directory(frozen)
    refs = dict(data['source_proofs'])
    refs.update(installed_wheel_proof=data['installed_wheel_proof'], kv_config=data['kv_config'],
                token_inputs=data['token_inputs'], oracle_rule=data['oracle_rule'])
    artifacts = {}
    for name, ref in refs.items():
        raw = checked(ref)
        dest = frozen / (name + '.json')
        dest.write_bytes(raw)
        artifacts[name] = dict(original=ref, frozen_path=str(dest), sha256=hashlib.sha256(raw).hexdigest())
        if name in ROLES and data['sources'][name] not in raw.decode():
            raise ValueError('source proof does not mention selected exact commit: ' + name)
    tokens = json.loads(checked(data['token_inputs']))
    for (kind, prompt, count), row in zip(PROMPTS, tokens['inputs'], strict=True):
        if row['id'] != kind or row['prompt'] != prompt or row['prompt_UTF8_sha256'] != hashlib.sha256(prompt.encode()).hexdigest() or row['token_count'] != count or len(row['token_ids']) != count:
            raise ValueError('independent original token/prompt freeze differs')
    model_files = {}
    for name in ('tokenizer.json', 'tokenizer_config.json', 'special_tokens_map.json', 'added_tokens.json', 'config.json', 'generation_config.json', 'merges.txt', 'vocab.json'):
        path = Path('/models/Qwen2.5-7B-Instruct') / name
        model_files[name] = dict(path=str(path), sha256=digest(path) if path.is_file() else None)
    for row in tokens['files']:
        path = Path(row['path'])
        if row['status'] == 'present' and digest(path) != row['sha256']:
            raise ValueError('independent tokenizer/config file changed')
        if row['status'] == 'absent' and path.exists():
            raise ValueError('original absent tokenizer option appeared')
    stats = Path(kv['method_config']['stats_path'])
    artifacts['calibration_stats'] = dict(path=str(stats), sha256=digest(stats), bytes=stats.stat().st_size)
    # Selected interpreter reads only stdlib metadata and source bytes, not Host.
    metadata_code = r'''
import importlib.metadata as m,hashlib,json,sys
names=['vllm','vllm-ascend','vllm-ascend-kvcompress-hust','vllm-request-lifecycle-profiler','vllm-hust-ext']
rows=[]
for name in names:
 d=m.distribution(name); members={}
 for f in d.files or []:
  if str(f).endswith(('.py','METADATA','entry_points.txt','direct_url.json')):
   p=d.locate_file(f)
   if p.is_file():members[str(f)]=hashlib.sha256(p.read_bytes()).hexdigest()
 rows.append(dict(name=name,version=d.version,root=str(d.locate_file('')),members=members))
print(json.dumps(dict(python=sys.executable,prefix=sys.prefix,distributions=rows),sort_keys=True))
'''
    # Metadata name varies across preexisting profiler wheel layouts; use the
    # exact installed name from explicit inputs rather than guessing on import.
    metadata_code = metadata_code.replace("'vllm-request-lifecycle-profiler'", repr(data['profiler_distribution']))
    argv = [data['python'], '-I', '-B', '-c', metadata_code]
    with (frozen / 'installed-source.stdout.json').open('wb') as stdout, (frozen / 'installed-source.stderr.log').open('wb') as stderr:
        p = subprocess.Popen(argv, stdout=stdout, stderr=stderr, start_new_session=True)
        proc = ident(p.pid)
        rc = p.wait(timeout=120)
    save(frozen / 'installed-source-Popen.json', dict(argv=argv, kernel=proc, returncode=rc))
    if rc:
        raise ValueError('actual selected runtime source metadata capture failed')
    installed = json.loads((frozen / 'installed-source.stdout.json').read_bytes())
    if Path(installed['prefix']) != Path(data['python']).parent.parent:
        raise ValueError('actual runtime prefix differs from explicit interpreter')
    campaign = dict(schema='ecpa-H2-three-method-neutral-cohort/v1', freeze=clock_pair(),
                    method=args.method, repeat_index=args.repeat_index, order_mode=args.order_mode,
                    source_commits=data['sources'], runtime_inputs_sha256=input_sha,
                    python=data['python'], runtime_metadata_capture_sha256=digest(frozen / 'installed-source.stdout.json'),
                    source_files={q.name: digest(q) for q in HERE.glob('*.py')}, artifacts=artifacts,
                    tokenizer_config_files=model_files, cases=CASES, physical_devices=[0, 3], runtime_devices=[0, 1],
                    ports=list(range(args.port_base, args.port_base + 5)),
                    original_requests=[dict(kind=kind, prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(), prompt_tokens=count) for kind, prompt, count in PROMPTS],
                    request_ids={name: [f'h2-{args.method}-r{args.repeat_index}-{name}-{kind}' for kind, _, _ in PROMPTS] for name, _ in CASES},
                    prompt_targets=[4, 1201], decode_tokens=32, request_timeout_s=240, health_timeout_s=720,
                    host_shutdown_timeout_s=5, full_prospective_starts=45, independent_pair_families=1,
                    complete45=False, formal_qualified=False, prediction=None, compatibility=None,
                    actual_human_effort=None, instrumentation_performance_clean=False,
                    clock_domains='RAW probe and MONOTONIC HTTP are distinct; clock_pair brackets only, never direct absolute comparison')
    save(root / 'campaign.json', campaign)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--runtime-inputs', type=Path, required=True)
    parser.add_argument('--method', choices=['native', 'manual', 'ecpa'], required=True)
    parser.add_argument('--repeat-index', type=int, choices=[1, 2, 3], required=True)
    parser.add_argument('--port-base', type=int, required=True)
    parser.add_argument('--order-mode', choices=['shared-explicit', 'official-observed'], required=True)
    args = parser.parse_args()
    if not args.root.is_absolute() or not 1024 <= args.port_base <= 65531:
        raise ValueError('new absolute block root and five valid consecutive ports required')
    data, kv, input_sha = load_inputs(args.runtime_inputs)
    os.umask(0o077)
    private_directory(args.root)
    lock = open('/run/ecpa-h2-npu-0-3.lock', 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        freeze_inputs(args.root, args, data, kv, input_sha)
        results = []
        for index, (name, selected) in enumerate(CASES):
            # Recheck immutable user inputs before each group, never reuse a
            # historical validity receipt as a new qualification.
            if digest(args.runtime_inputs) != input_sha:
                raise ValueError('runtime declaration changed after freeze')
            for ref in [data['installed_wheel_proof'], *data['source_proofs'].values(), data['kv_config'], data['token_inputs'], data['oracle_rule']]:
                checked(ref)
            row = execute(args.root, name, selected, data, kv, args.method, args.repeat_index, args.order_mode, args.port_base + index)
            results.append(row)
            save(args.root / 'outcome.json', results)
            if row['owned_survivors'] or not row['device_process_tables_empty'] or not row['port_closed'] or row.get('returncode') is None:
                raise RuntimeError('real cleanup incomplete; subsequent groups not attempted')
        save(args.root / 'block-terminal.json', dict(clock=clock_pair(), starts_attempted=len(results), required_groups=5,
             all_attempts_retained=True, all_functional=all(not r['error'] for r in results),
             formal_qualified=False, compatibility=None, full45_complete=False))
    finally:
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()


if __name__ == '__main__':
    main()
