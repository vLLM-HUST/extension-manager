"""Optional future serial 45-start driver; never auto-arms on source creation."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

from ownership import ident
from run_three_methods import HERE, digest, load_inputs, private_directory, save


def build_schedule(root, runtime_inputs, port_base, order_mode):
    if type(port_base) is not int or port_base < 1024 or port_base + 84 > 65535:
        raise ValueError('full45 requires all nine five-port blocks in valid range')
    schedule = []
    orders = [('native', 'manual', 'ecpa'), ('manual', 'ecpa', 'native'), ('ecpa', 'native', 'manual')]
    for repeat, methods in enumerate(orders, 1):
        for method in methods:
            label = f'{method}-r{repeat}'
            index = len(schedule)
            block_port = port_base + 10 * index
            argv = [sys.executable, '-B', str(HERE / 'run_three_methods.py'), '--root', str(root / label),
                    '--runtime-inputs', str(runtime_inputs.resolve()), '--method', method, '--repeat-index', str(repeat),
                    '--port-base', str(block_port), '--order-mode', order_mode]
            schedule.append(dict(label=label, method=method, repeat_index=repeat, groups=5,
                                 block_index=index, ports=list(range(block_port, block_port + 5)), argv=argv))
    return schedule


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', required=True, type=Path)
    parser.add_argument('--runtime-inputs', required=True, type=Path)
    parser.add_argument('--port-base', required=True, type=int)
    parser.add_argument('--order-mode', required=True, choices=['shared-explicit', 'official-observed'])
    args = parser.parse_args()
    data, kv, input_sha = load_inputs(args.runtime_inputs)
    schedule = build_schedule(args.root, args.runtime_inputs, args.port_base, args.order_mode)
    private_directory(args.root)
    save(args.root / 'schedule.json', dict(schema='ecpa-H2-three-method-neutral-schedule/v1',
         input_sha256=input_sha, source=digest(Path(__file__)), blocks=schedule,
         starts=45, pair_families=1, order_policy='Latin: native/manual/ecpa; manual/ecpa/native; ecpa/native/manual', verdict=None))
    for block in schedule:
        if digest(args.runtime_inputs) != input_sha:
            raise ValueError('input identity changed across blocks')
        log = args.root / block['label']
        with log.with_suffix('.stdout.log').open('xb') as stdout, log.with_suffix('.stderr.log').open('xb') as stderr:
            child = subprocess.Popen(block['argv'], stdout=stdout, stderr=stderr, start_new_session=True)
            kernel = ident(child.pid)
            save(log.with_suffix('.Popen.json'), dict(kernel=kernel, argv=block['argv'], monotonic_ns=time.monotonic_ns()))
            rc = child.wait()
        save(log.with_suffix('.terminal.json'), dict(returncode=rc, monotonic_ns=time.monotonic_ns()))
        if rc:
            raise RuntimeError('block failed or cleanup unknown; no retry/subsequent block')
        terminal = json.loads((log / 'block-terminal.json').read_bytes())
        if terminal['starts_attempted'] != 5:
            raise ValueError('incomplete block; cannot continue as completed45')
    save(args.root / 'schedule-terminal.json', dict(starts_attempted=45, pair_families=1,
         original_results_retained=True, compatibility=None, formal_qualified=False))


if __name__ == '__main__':
    main()
