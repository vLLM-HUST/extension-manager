# Executable future three-method neutral H2 runner

**Not launched.** This candidate does not change r6, any installed package,
product source, process or device. `run_three_methods.py` actually implements one
method/repetition's five starts; it is not a command-template-only generator.
`run_full_45.py` optionally executes nine such blocks sequentially, retaining
negative functional results, stopping on cleanup/unknown launcher failure, with
no retries. 45 starts remain **one KVCompress+Profiler pair family**, not45
independent compatibility cases or coverage of the MOD population.

Root launches only after the active cohort has released the devices:

```
/ABS/management-python -B /ABS/candidate/run_three_methods.py \
  --root /ABS/NEW/native-r1 --runtime-inputs /ABS/actual-runtime-inputs.json \
  --method native --repeat-index 1 --port-base 29941 --order-mode shared-explicit
```

For all45 use `run_full_45.py` with the same arguments except method/repeat;
it freezes the original Latin method order before any Popen:
native/manual/ecpa; manual/ecpa/native; ecpa/native/manual. Each block uses
five ports beginning at base+10*block_index; the full range must fit1024..65535.
Each block has its own root, configs, study nonce, original requests/RIDs,
stdout/stderr, neutral files, installed source snapshot, raw-file hashes and
cleanup result. The same5 ports can be reused only after actual previous
cleanup. A source-qualified negative is not automatically formal: compatibility
and native qualification remain null/false pending the independent raw reader.

## Explicit runtime inputs (no silent053→259 substitution)

The required JSON schema is `ecpa-H2-three-method-runtime-inputs/v1`:

- `python`: exact absolute runtime interpreter, currently root may supply
  `/root/ecpa-workspace/environments/ecpa-h2-drain-20261019-r1/bin/python`.
- `environment`: actual admitted base CANN/runtime environment. Stale Manager,
  semantic/bootstrap/direct-MOD controls are removed, then only method-specific
  declared fields are set. This is not an ECPA resolved child environment.
- `sources`: full40hex commits keyed `manager,host,ascend,kv,profiler`.
- `source_proofs`: those same five keys, each `{path,sha256}` pointing to retained
  actual source/build/installed comparison evidence. Each checked proof must
  contain its exact selected commit. This management runner freezes these
  reports, not a replacement source-qualification authority.
- `installed_wheel_proof`: SHA-checked `{path,sha256}` for the selected runtime's
  actual wheel/installed verification; cannot reuse a report for another prefix.
- `kv_config`: SHA-checked actual direct-provider inner JSON, currently the input
  in `baseline-native-h2-wiring/kv-provider-intent.json`, not a resolvedenv.
- `token_inputs`: SHA-checked original `independent-inputs/actual-tokenizer-inputs.json`.
- `oracle_rule`: SHA-checked `compatible-oracle-rule-drain-v2.json` (a prospective
  rule, not an oracle result).
- `profiler_distribution`: actual METADATA Name, current runtime
  `vllm-request-lifecycle-profiler-plugin`.

Bare and `sha256:`-prefixed full SHA256 refs are accepted. Root must supply a
fresh/new verified runtime packet when changing Manager to259 or any wheel.
The runner freezes input ref bytes, full source pins, actual installed .py and
METADATA/entrypoint source hashes from the selected interpreter, tokenizer/config
files, original token IDs4/1201, PT calibration bytes, oracle, ports, clocks,
loader/probe/common method intent before the first **product** Popen. Its
stdlib-only metadata subprocess is recorded separately, not a Host start.
It does not import Host, Torch or a model in metadata capture. No Manager commit
is hardcoded in executable code. An old installed-wheel proof cannot be treated
as independent proof for a new prefix merely by changing this JSON.

## Actual methods and common instrumentation

Five groups: Host only, KV only, Profiler only, KV→Profiler, Profiler→KV.
Native uses official direct KV enable/config and, for Profiler, the actual
`python -m vllm_request_lifecycle_profiler.launcher`. Manual uses the same
supported direct KV environment and Host main; no fictitious repair effort is
inserted when official integration already suffices. ECPA uses real
`vllm-hust-ext run -- <same Host>` with the same KV inner provider configuration.
Only ECPA has its actual Manager input; no baseline gets a Plan/ACK invented by
this script. A singleton needing no manual repair is honestly recorded as such.

`shared-explicit` applies one identical metadata-order adapter to all methods.
`official-observed` keeps actual entrypoint discovery order (no sort), records
actual callback starts/completions, and does not pretend comma-separated
VLLM_PLUGINS order is execution order. Opposite pair labels then mean requested
order only; independence requires checking actual per-process callbacks. Shared
explicit order is a research/manual adapter cost, not an ECPA-only capability.

Same after-general-loader EventBus/mapping observers and neutral NPU wrapper
are used for every method, including Host only. The wrapper calls the original
Host upload function first, leaving all real guards/bootstrap/ACK intact. It
adds actual same-stream barrier and synchronous CPU/NPU prefix readback for all
active RIDs/groups, recording true Host7+kernel4 without requiring/fabricating
Plan bindings. Probe errors are unknown, not compatibility conflict. Active
prefix invalid integer IDs are unknown; actual unequal or unstable valid values
remain raw observed false. The helper's chain provides integrity checks, not
independent producer authentication. Original authenticated ECPA observer may
add another barrier/copy: this is disclosed and is **not clean production
performance data**. RAW probe and MONOTONIC HTTP clocks have paired samples;
absolute values are not directly compared across domains.

All exact Host flags stay TP2, device0/3 via runtime0/1, maxseq1, eager,
maxlen2048, memory0.6, block128, no prefix cache, chunked prefill, shutdown5.
Two actual requests per group use original below4/above1201 prompts, max32,
ignore_eos, seed20261019, temperature0, and a real absolute240-second HTTP
budget with owned-socket watchdog. Unique RID includes method/repeat/group.
Actual HTTP usage must independently match4/1201+32; Rust-only tokenizer IDs
are not asserted equal to Host AutoTokenizer merely by shared config.

## Ownership, failures and future checks

The five r6 `ident/current/capture/send/npu` functions are exact AST copies,
recorded in ownership-AST-proof.json. The root obtains the same exclusive NPU
lock, checks actual empty device tables, tracks actual descendants, uses owned
pidfds, allows normal shutdown, then retains any TERM/KILL cleanup. New private
block/group/neutral directories use a pinned owned directory FD and explicit
fchmod0700 to clear inherited SGID **before descendants**. No cleanup success
is prefilled. Unknown survivors, nonempty NPU or open port stop the block and
schedule. No external process is signaled. Root's independent process/FD/NPU
inventory remains necessary; this owned-tree cleanup is not its replacement.

New source-only tests cover all three command/env branches, inherited-SGID
removal and original case/count identity. They are NOT RUN. The earlier neutral
helper's4 semantic tests passed but do not validate this new runner, real NPU,
new integer-boundary delta or future runtime. No fake NPU test is represented
as an experiment. Minimum next checks are these tiny tests, source review of
root's exact runtime proof packet, then actual root-owned cohort launch; no
new algorithm patch or model workload tuning is part of this candidate.

## r2 listener and schedule correction

Original r1 remains sealed. Cleanup now checks actual IPv4 connect refusal
(`connect_ex == ECONNREFUSED`), never bind availability or SO_REUSEADDR. A live
listener is not released; other connection outcomes remain unknown/not closed.
A real closed server with retained server-port TIME_WAIT is released. This is
checked after the original owned process/pidfd/NPU cleanup, not a substitute
for it. The original prelaunch bind still detects port conflicts before any
product launch; distinct port blocks avoid reusing another block's TIME_WAIT.

Actual CPU4 tiny validation:8PASS in0.10s, including real server-initiated FIN,
observed /proc TCP TIME_WAIT, actual old bind EADDRINUSE and new connect refusal;
live listener rejection; all45 unique ports and Latin/boundary checks; and the
original5 command/env/private-mode cases. No products/models/NPU were imported
or launched. Logs and actual Popen/rc are in validation-attempt-01. No HTTP240,
shutdown5, ownership signal scope, NPU empty predicate or MOD algorithms changed.
