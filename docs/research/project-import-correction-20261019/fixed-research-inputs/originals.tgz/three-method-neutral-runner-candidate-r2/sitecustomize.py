"""Shared study instrumentation: order actual callbacks; never alter MOD algorithms."""
import dataclasses
import functools
import importlib.metadata as metadata
from importlib.machinery import PathFinder
import json
import os
import sys
import time
from pathlib import Path

_original = metadata.entry_points
_probe_pid = None
_observer = None


def record(kind, **fields):
    root = os.environ.get('ECPA_H2_RAW')
    if not root:
        return
    stat = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()
    row = dict(kind=kind, pid=os.getpid(), start_ticks=int(stat[19]),
               clock_pair=dict(monotonic_ns=time.monotonic_ns(), raw_ns=time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)),
               monotonic_ns=time.monotonic_ns(), **fields)
    fd = os.open(str(Path(root) / 'study-events.jsonl'), os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        os.write(fd, (json.dumps(row, default=str, sort_keys=True) + '\n').encode())
    finally:
        os.close(fd)


def install_observer():
    global _probe_pid, _observer
    if _probe_pid == os.getpid():
        return
    from vllm.v1.events import EventBus
    from vllm.plugins import native_block_table_observer as native

    if not getattr(native.observe_request_id_mapping, '__h2_mapping__', False):
        original_mapping = native.observe_request_id_mapping

        @functools.wraps(original_mapping)
        def mapped(request):
            answer = original_mapping(request)
            record('actual-request-mapping', external_request_id=request.external_req_id,
                   runtime_request_id=request.request_id,
                   prompt_token_ids=getattr(request, 'prompt_token_ids', None))
            return answer

        mapped.__h2_mapping__ = True
        native.observe_request_id_mapping = mapped
    # Neutral study never registers an authenticated native observer.
    # Original Host bootstrap/observers and their guards remain untouched.

    if os.environ.get('ECPA_NEUTRAL_NPU_DIRECTORY'):
        from neutral_npu_probe import install
        from vllm.plugins.evidence import capture_scope
        install(native, capture_scope)

    class Observer:
        def emit(self, event):
            if type(event).__name__ not in {'RequestFinished', 'RequestKvReclaimed', 'RequestPreempted'}:
                return
            fields = dataclasses.asdict(event) if dataclasses.is_dataclass(event) else {
                k: getattr(event, k) for k in ('request_id', 'kv_blocks', 'prompt_tokens', 'output_tokens', 'sequence_tokens') if hasattr(event, k)
            }
            record('host-event', event_type=type(event).__name__, fields=fields)

    if _observer is not None:
        EventBus.unregister_sink(_observer)
    _observer = Observer()
    EventBus.register_sink(_observer)
    _probe_pid = os.getpid()
    record('study-observer-installed')


class OrderedEntry:
    def __init__(self, entry):
        self.entry = entry

    def __getattr__(self, key):
        return getattr(self.entry, key)

    def load(self):
        fn = self.entry.load()

        @functools.wraps(fn)
        def invoke(*args, **kwargs):
            record('callback-start', name=self.name, value=self.value)
            try:
                result = fn(*args, **kwargs)
            except BaseException as error:
                record('callback-error', name=self.name, error=repr(error))
                raise
            record('callback-complete', name=self.name, value=self.value)
            return result

        return invoke


def ordered_entries(**kwargs):
    entries = _original(**kwargs)
    if kwargs.get('group') != 'vllm.general_plugins' or not os.environ.get('ECPA_H2_RAW'):
        return entries
    order = ['ascend', *json.loads(os.environ['ECPA_H2_ORDER'])]
    rank = {name: n for n, name in enumerate(order)}
    mode = os.environ['ECPA_H2_ORDER_MODE']
    if mode == 'shared-explicit':
        entries = sorted(entries, key=lambda e: rank.get(e.name, 100))
    elif mode != 'official-observed':
        raise ValueError('unknown study order mode')
    return tuple(OrderedEntry(e) for e in entries)


metadata.entry_points = ordered_entries


class _AfterGeneralLoader:
    """Delegate original module loading, then wrap only the public load boundary."""

    def __init__(self, delegate):
        self._delegate = delegate

    def __getattr__(self, key):
        return getattr(self._delegate, key)

    def create_module(self, spec):
        method = getattr(self._delegate, 'create_module', None)
        return method(spec) if method is not None else None

    def exec_module(self, module):
        self._delegate.exec_module(module)
        original_load = module.load_general_plugins

        @functools.wraps(original_load)
        def loaded(*args, **kwargs):
            # Original callback errors propagate. No observer is installed as
            # though a failed original load had completed.
            answer = original_load(*args, **kwargs)
            install_observer()
            record('general-load-complete-observer-installed',
                   original_module=original_load.__module__,
                   original_qualname=original_load.__qualname__,
                   original_code_filename=original_load.__code__.co_filename)
            return answer

        module.load_general_plugins = loaded


class _AfterGeneralFinder:
    def find_spec(self, fullname, path=None, target=None):
        if fullname != 'vllm.plugins':
            return None
        # Exact original regular Host package; do not import platform, Torch,
        # or any MOD from sitecustomize or from a platform callback.
        spec = PathFinder.find_spec(fullname, path, target)
        if spec is None or spec.loader is None:
            raise ImportError('study cannot locate original vllm.plugins')
        spec.loader = _AfterGeneralLoader(spec.loader)
        return spec


if os.environ.get('ECPA_H2_RAW'):
    if 'vllm.plugins' in sys.modules:
        raise RuntimeError('study hook too late: original Host loader already imported')
    sys.meta_path.insert(0, _AfterGeneralFinder())
