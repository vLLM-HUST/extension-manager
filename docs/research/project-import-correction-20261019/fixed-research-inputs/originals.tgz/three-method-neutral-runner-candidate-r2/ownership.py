import os
import signal
import subprocess
from pathlib import Path
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()

def ident(pid):
    s = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=pid, start_ticks=int(s[19]), session=int(s[3]), state=s[0], boot_id=BOOT)

def current(item):
    try:
        now = ident(item['pid'])
        return now['start_ticks'] == item['start_ticks'] and now['session'] == item['session'] and now['state'] != 'Z'
    except FileNotFoundError:
        return False

def capture(pid, seen):
    try:
        item = ident(pid)
        seen[(pid, item['start_ticks'])] = item
        for child in Path(f'/proc/{pid}/task/{pid}/children').read_text().split():
            capture(int(child), seen)
    except (FileNotFoundError, ProcessLookupError):
        pass

def send(item, sig):
    if not current(item):
        return
    fd = os.pidfd_open(item['pid'])
    try:
        if current(item):
            signal.pidfd_send_signal(fd, sig)
    finally:
        os.close(fd)

def npu(path):
    p = subprocess.run(['npu-smi', 'info'], capture_output=True, text=True, timeout=30)
    path.write_text(p.stdout + p.stderr)
    if p.returncode or p.stdout.count('No running processes found') != 2:
        raise RuntimeError('allocated NPU process tables are not empty; retained inventory')
