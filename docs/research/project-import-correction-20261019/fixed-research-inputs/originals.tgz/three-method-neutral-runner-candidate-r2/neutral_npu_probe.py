"""Research-only upload readback. No Plan mint, observer registration or ACK."""
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import stat
import threading
import time

SCHEMA = 'ecpa-neutral-npu-upload-study/v1'
_lock = threading.Lock()
_owner = None
_sequence = 0
_previous = '0' * 64


def _fork_reset():
    global _lock, _owner, _sequence, _previous
    _lock = threading.Lock()
    _owner = None
    _sequence = 0
    _previous = '0' * 64


os.register_at_fork(after_in_child=_fork_reset)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def kernel():
    fields = Path('/proc/self/stat').read_text().rsplit(')', 1)[1].split()
    return dict(pid=os.getpid(), start_ticks=int(fields[19]), session=int(fields[3]),
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())


def source(fn):
    path = Path(inspect.getsourcefile(fn)).resolve(strict=True)
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                function=fn.__qualname__, line=inspect.getsourcelines(fn)[1])


def emit(payload):
    """Separate per-epoch chain; a write error propagates, never claims evidence."""
    global _owner, _sequence, _previous
    directory = Path(os.environ['ECPA_NEUTRAL_NPU_DIRECTORY'])
    nonce = os.environ['ECPA_NEUTRAL_NPU_NONCE']
    if len(nonce) != 64 or any(c not in '0123456789abcdef' for c in nonce):
        raise ValueError('neutral study nonce must be 64 lowercase hex characters')
    if str(directory.resolve(strict=True)) != str(directory):
        raise ValueError('neutral directory must be canonical and nonsymlink')
    dfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        ds = os.fstat(dfd)
        if ds.st_uid != os.geteuid() or stat.S_IMODE(ds.st_mode) != 0o700:
            raise ValueError('neutral directory requires owned private mode0700')
        identity = kernel()
        with _lock:
            if _owner not in (None, identity):
                raise RuntimeError('neutral writer epoch changed without fork reset')
            _owner = identity
            row = dict(schema=SCHEMA, trace_nonce=nonce, kernel=identity,
                       sequence=_sequence, previous_sha256=_previous,
                       raw_ns=time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW), **payload)
            row['event_sha256'] = hashlib.sha256(canonical(row)).hexdigest()
            name = f"neutral-{identity['pid']}-{identity['start_ticks']}-{nonce}.jsonl"
            flags = os.O_WRONLY | os.O_APPEND | os.O_NOFOLLOW
            flags |= os.O_CREAT | os.O_EXCL if _sequence == 0 else 0
            fd = os.open(name, flags, 0o600, dir_fd=dfd)
            try:
                fs = os.fstat(fd)
                if not stat.S_ISREG(fs.st_mode) or fs.st_uid != os.geteuid() or stat.S_IMODE(fs.st_mode) != 0o600 or fs.st_nlink != 1:
                    raise ValueError('unsafe neutral evidence file')
                body = canonical(row) + b'\n'
                while body:
                    written = os.write(fd, body)
                    if written <= 0:
                        raise OSError('neutral evidence write made no progress')
                    body = body[written:]
            finally:
                os.close(fd)
            _sequence += 1
            _previous = row['event_sha256']
    finally:
        os.close(dfd)


def read_upload(runner, scheduled_output, capture_scope):
    """Read only active prefixes after current-stream barrier, for every method."""
    import torch  # Only at actual worker upload callback, never site startup.

    before = kernel()
    scope = capture_scope(expected_role='worker')
    host = scope['process']
    if (host['assignment_source'] != 'host' or host['pid'] != before['pid']
            or host['start_identity'] != f"pid:{before['pid']}:start_ticks:{before['start_ticks']}"):
        raise ValueError('neutral callback requires actual Host-bound worker epoch')
    batch = runner.input_batch
    count = batch.num_reqs
    if type(count) is not int:
        raise ValueError('actual batch row count must be a true int')
    ids = list(batch.req_ids[:count])
    if count <= 0 or len(ids) != count or any(not isinstance(r, str) or not r for r in ids) or len(set(ids)) != count:
        raise ValueError('invalid actual runtime request inventory')
    tables = list(batch.block_table.block_tables)
    if not tables:
        raise ValueError('actual block-table groups missing')
    device = tables[0].block_table.gpu.device
    if device.type != 'npu' or any(t.block_table.gpu.device != device for t in tables):
        raise ValueError('neutral probe requires actual same-device NPU tables')
    stream = torch.npu.current_stream(device)
    start = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
    stream.synchronize()
    barrier_end = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
    observed = []
    for row, request_id in enumerate(ids):
        scheduled = scheduled_output.num_scheduled_tokens.get(request_id, 0)
        if scheduled <= 0:
            continue
        groups = []
        for group, table in enumerate(tables):
            width = int(table.num_blocks_per_row[row])
            if width <= 0 or width > table.block_table.gpu.shape[1]:
                raise ValueError('invalid active uploaded prefix width')
            cpu = table.block_table.np[row, :width].tolist()
            gpu = table.block_table.gpu[row, :width].to(device='cpu', non_blocking=False).tolist()
            cpu_after = table.block_table.np[row, :width].tolist()
            if any(type(v) is not int or v < 0 for values in (cpu, gpu, cpu_after) for v in values):
                raise ValueError('active block IDs must be nonnegative true integers')
            stable = cpu == cpu_after
            groups.append(dict(group=group, row=row, width=width, cpu_prefix=cpu,
                               npu_prefix=gpu, cpu_prefix_after=cpu_after, cpu_prefix_stable=stable, prefixes_equal=cpu == gpu))
        observed.append(dict(runtime_request_id=request_id, row=row,
                             scheduled_tokens=scheduled, groups=groups))
    end = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
    if before != kernel() or capture_scope(expected_role='worker')['process'] != host:
        raise ValueError('worker scope changed during neutral readback')
    return dict(host_process=host, kernel_before=before, kernel_after=kernel(),
                binding_status_observed=scope['binding_status'], device=str(device),
                stream_repr=repr(stream), barrier_begin_raw_ns=start,
                barrier_end_raw_ns=barrier_end, readback_end_raw_ns=end,
                requests=observed, prefix_readback_only=True,
                kv_tensor_equivalence=None, attention_consumption=None,
                authenticated_native_proof=None)


def install(native, capture_scope):
    """Install after original general-plugin loader; preserve original exceptions."""
    original = native.observe_block_table_upload
    if getattr(original, '__neutral_npu_study__', False):
        return
    original_source = source(original)
    evidence_source = source(capture_scope)

    @functools.wraps(original)
    def wrapped(runner, scheduler_output):
        entered = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
        observer_before = native._observer is not None
        # Original guard/bootstrap/selection/ACK always executes first, unchanged.
        answer = original(runner, scheduler_output)
        original_return = time.clock_gettime_ns(time.CLOCK_MONOTONIC_RAW)
        observer_after = native._observer is not None
        try:
            payload = read_upload(runner, scheduler_output, capture_scope)
        except Exception as error:
            emit(dict(event='probe-unknown', exception_type=type(error).__module__ + '.' + type(error).__qualname__,
                      original_enter_raw_ns=entered, original_return_raw_ns=original_return,
                      original_observer_before=observer_before, original_observer_after=observer_after,
                      original_source=original_source, evidence_source=evidence_source))
        else:
            emit(dict(event='upload-readback', original_enter_raw_ns=entered,
                      original_return_raw_ns=original_return,
                      original_observer_before=observer_before, original_observer_after=observer_after,
                      original_source=original_source, evidence_source=evidence_source, **payload))
        return answer

    wrapped.__neutral_npu_study__ = True
    native.observe_block_table_upload = wrapped
