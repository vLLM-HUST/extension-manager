"""Offline source-study checks, never a native authorization/qualification API."""
import hashlib
import json

from neutral_npu_probe import SCHEMA, canonical


def verify_rows(rows, *, expected_kernel, expected_host, expected_nonce):
    previous = '0' * 64
    observations = []
    unknown = 0
    for sequence, row in enumerate(rows):
        bare = {k: v for k, v in row.items() if k != 'event_sha256'}
        if (row['schema'] != SCHEMA or row['kernel'] != expected_kernel
                or row['trace_nonce'] != expected_nonce or row['sequence'] != sequence
                or row['previous_sha256'] != previous
                or hashlib.sha256(canonical(bare)).hexdigest() != row['event_sha256']):
            raise ValueError('neutral trace identity/hashchain mismatch')
        previous = row['event_sha256']
        if row['original_enter_raw_ns'] > row['original_return_raw_ns'] or row['original_return_raw_ns'] > row['raw_ns']:
            raise ValueError('neutral original callback clock order')
        if row['event'] == 'probe-unknown':
            unknown += 1
            continue
        if row['event'] != 'upload-readback':
            raise ValueError('unknown neutral event')
        if (row['host_process'] != expected_host or expected_host['assignment_source'] != 'host'
                or expected_host['role'] != 'worker' or expected_host['pid'] != expected_kernel['pid']
                or expected_host['start_identity'] != f"pid:{expected_kernel['pid']}:start_ticks:{expected_kernel['start_ticks']}"
                or row['kernel_before'] != expected_kernel or row['kernel_after'] != expected_kernel):
            raise ValueError('neutral Host7/kernel identity mismatch')
        clocks = [row[k] for k in ('original_return_raw_ns', 'barrier_begin_raw_ns',
                                   'barrier_end_raw_ns', 'readback_end_raw_ns', 'raw_ns')]
        if clocks != sorted(clocks):
            raise ValueError('neutral readback clock order')
        ids = set()
        for request in row['requests']:
            rid = request['runtime_request_id']
            if not isinstance(rid, str) or not rid or rid in ids or request['scheduled_tokens'] <= 0:
                raise ValueError('invalid neutral runtime RID')
            ids.add(rid)
            if not request['groups']:
                raise ValueError('missing neutral block groups')
            for index, group in enumerate(request['groups']):
                if (any(type(group[k]) is not int for k in ('group', 'row', 'width'))
                        or type(request['row']) is not int or request['row'] < 0
                        or any(type(v) is not int or v < 0 for values in (group['cpu_prefix'], group['npu_prefix'], group['cpu_prefix_after']) for v in values)
                        or group['group'] != index or group['row'] != request['row']
                        or group['width'] <= 0 or len(group['cpu_prefix']) != group['width']
                        or len(group['npu_prefix']) != group['width']
                        or len(group['cpu_prefix_after']) != group['width']
                        or group['cpu_prefix_stable'] != (group['cpu_prefix'] == group['cpu_prefix_after'])
                        or group['prefixes_equal'] != (group['cpu_prefix'] == group['npu_prefix'])):
                    raise ValueError('corrupt neutral prefix observation')
            observations.append(dict(runtime_request_id=rid,
                                     equal_and_stable=all(g['prefixes_equal'] and g['cpu_prefix_stable'] for g in request['groups'])))
    return dict(schema='ecpa-neutral-npu-study-summary/v1', recorded_uploads=observations,
                unknown_events=unknown, source_complete=None, authenticated_native_proof=False,
                kv_tensor_equivalence=None, compatibility_oracle=None,
                performance_comparison_qualified=False)


def read_trace(path, **expected):
    with open(path, 'rb') as stream:
        rows = [json.loads(line) for line in stream]
    if not rows:
        raise ValueError('no neutral evidence; not proof of zero uploads')
    return verify_rows(rows, **expected)
