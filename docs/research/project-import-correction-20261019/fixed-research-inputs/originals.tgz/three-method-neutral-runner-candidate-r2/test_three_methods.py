"""Pure candidate command/env tests only: no product import, Popen, device or payload."""
import json
from pathlib import Path

import pytest

import run_three_methods as runner


def data():
    return dict(environment={'ECPA_STALE': 'bad', 'VLLM_HUST_EXT_CONFIG': 'old', 'VLLM_ASCEND_KVCOMPRESS_ENABLED': '1'},
                sources={role: 'a' * 40 for role in runner.ROLES})


@pytest.mark.parametrize('method', ['native', 'manual', 'ecpa'])
def test_actual_method_argv_and_direct_config(method):
    selected = [runner.KV, runner.PROF]
    env = runner.environment(data(), Path('/NEW'), selected, method, 'shared-explicit', Path('/NEW/kv.json'), Path('/NEW/manager.json'))
    argv = runner.command(Path('/VENV/bin/python'), selected, method, 29941)
    assert 'ECPA_STALE' not in env
    assert env['VLLM_PLUGINS'] == 'ascend,ascend_kvcompress,request_lifecycle_profiler'
    assert env['ECPA_H2_ORDER_MODE'] == 'shared-explicit'
    assert json.loads(env['ECPA_H2_ORDER']) == selected
    assert len(env['ECPA_NEUTRAL_NPU_NONCE']) == 64
    assert 'VLLM_ECPA_PLAN_ID' not in env
    assert 'VLLM_ECPA_LAUNCH_ID' not in env
    if method == 'ecpa':
        assert argv[:3] == ['/VENV/bin/vllm-hust-ext', 'run', '--']
        assert 'VLLM_ASCEND_KVCOMPRESS_ENABLED' not in env
        assert env['VLLM_HUST_EXT_CONFIG'] == '/NEW/manager.json'
    else:
        assert env['VLLM_ASCEND_KVCOMPRESS_CONFIG'] == '/NEW/kv.json'
        assert 'VLLM_HUST_EXT_CONFIG' not in env
        assert argv[2] == ('vllm_request_lifecycle_profiler.launcher' if method == 'native' else 'vllm.entrypoints.cli.main')
    assert argv[argv.index('--max-num-seqs') + 1] == '1'
    assert argv[argv.index('--shutdown-timeout') + 1] == '5'


def test_private_directory_removes_inherited_setgid(tmp_path):
    tmp_path.chmod(0o2700)
    child = tmp_path / 'neutral'
    runner.private_directory(child)
    assert child.stat().st_mode & 0o7777 == 0o700


def test_no_case_or_count_relabel():
    assert len(runner.CASES) == 5
    assert [n for _, _, n in runner.PROMPTS] == [4, 1201]
    assert runner.CASES[-2][1] == list(reversed(runner.CASES[-1][1]))


def test_closed_server_time_wait_is_not_listener():
    import errno
    import socket
    import time

    server = socket.socket()
    client = socket.socket()
    accepted = None
    try:
        server.bind(('127.0.0.1', 0))
        port = server.getsockname()[1]
        server.listen(1)
        client.connect(('127.0.0.1', port))
        accepted, _ = server.accept()
        accepted.shutdown(socket.SHUT_WR)  # Actual server initiates FIN.
        assert client.recv(1) == b''
        client.close()
        accepted.close()
        server.close()
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            states = [line.split()[3] for line in Path('/proc/net/tcp').read_text().splitlines()[1:]
                      if int(line.split()[1].split(':')[1], 16) == port]
            if '06' in states:
                break
            time.sleep(0.01)
        assert '06' in states, 'must observe actual server-port TIME_WAIT'
        # Demonstrate the original false rejection using an actual plain bind.
        with socket.socket() as retry:
            with pytest.raises(OSError) as caught:
                retry.bind(('127.0.0.1', port))
            assert caught.value.errno == errno.EADDRINUSE
        assert runner.port_is_closed(port)
    finally:
        client.close()
        if accepted is not None:
            accepted.close()
        server.close()


def test_actual_live_listener_is_not_closed():
    import socket

    with socket.socket() as server:
        server.bind(('127.0.0.1', 0))
        server.listen(1)
        assert not runner.port_is_closed(server.getsockname()[1])


def test_full_schedule_latin_and_unique_port_blocks(tmp_path):
    from run_full_45 import build_schedule

    schedule = build_schedule(tmp_path, tmp_path / 'inputs.json', 29941, 'shared-explicit')
    assert [[b['method'] for b in schedule[n:n + 3]] for n in (0, 3, 6)] == [
        ['native', 'manual', 'ecpa'], ['manual', 'ecpa', 'native'], ['ecpa', 'native', 'manual']]
    ports = [port for block in schedule for port in block['ports']]
    assert len(ports) == len(set(ports)) == 45
    for index, block in enumerate(schedule):
        assert block['ports'] == list(range(29941 + 10 * index, 29946 + 10 * index))
        assert block['argv'][block['argv'].index('--port-base') + 1] == str(29941 + 10 * index)
    assert build_schedule(tmp_path, tmp_path / 'inputs.json', 65451, 'official-observed')[-1]['ports'][-1] == 65535
    for invalid in (1023, 65452, True):
        with pytest.raises(ValueError, match='full45'):
            build_schedule(tmp_path, tmp_path / 'inputs.json', invalid, 'shared-explicit')
