# ECPA：真实 MOD 组合与 OSDI ’27 研究进展

本页汇总 ECPA 已核验的实现、实验、反例和缺口，执行总账为 [extension-manager #66](https://github.com/vLLM-HUST/extension-manager/issues/66)，原验收范围为 #59–#65。原始证据、固定输入、历史失败和机器可读清单见[本仓 campaign](../../results/campaigns/ecpa-osdi/README.md)。本次同步不改变任何旧实验的资格或分数。

## 主线与工程问题

研究主线已调整为：**真实推理 MOD 的接口、隐式依赖和组合冲突，如何变成可检查的契约，并在实际进程和请求上验证效果。** 当前稿题为 *Making LLM Inference Extensions Compose: Contracts for Interfaces, Dependencies, and Runtime Effects*。故障注入保留为 H3 支撑实验，不再替代 MOD 组合主线。

| 实际发现的问题 | 当前 ECPA/宿主处理 | 证据与边界 |
|---|---|---|
| package/entrypoint、模型/版本/拓扑、KV状态格式和共享hook的依赖分散在源码与环境变量 | 固定源版本，提取明确前提、配置和资源约束，交由通用compiler检查；unknown保留 | 已完成源码审计和部分真实组合；尚非自动抽取全部MOD契约 |
| Pipeline 要求 PP≥2，而所选 KV provider 要求 PP=1；stock没有识别此组合 | 显式 source adapter 将两个前提送入真实通用compiler，两种顺序均拒绝 | [Manager #259](https://github.com/vLLM-HUST/extension-manager/pull/259)已合并；stock漏检保留。这是源级矛盾，未伪称已跑native干扰或算法普遍互斥 |
| entrypoint集合/CSV顺序不能证明实际逐进程回调顺序 | 同时保留requested order与API/scheduler/TP0/TP1实际callback start/complete | 公共显式排序研究适配器对三方法共同计成本，不算ECPA独享能力 |
| host-only没有general MOD回调时，原study observer未初始化 | 在原宿主general-loader成功返回后统一初始化公共观测 | r5另立新运行验证；原r4未知保持不变 |
| Profiler依赖atexit，Host强杀可绕过scheduler/worker关闭汇总 | 原EventBus支持可选sink.close，在EngineCore/worker退出前drain；Profiler复用原RuntimeLifecycleHooks.close | [Host #67](https://github.com/vLLM-HUST/vllm-hust/pull/67)、[Profiler #35](https://github.com/vLLM-HUST/vllm-hust-request-lifecycle-profiler/pull/35)已合并；两仓生产改动合计+51/−1，原失败CI与修复均留证 |
| native/manual没有ECPA Plan，原认证observer不能直接充当公共测量 | 独立neutral研究探针：原上传回调先执行，再在真实NPU同stream读回active prefix，诚实记录unbound Host7/kernel/rank/RID | 新三方法真实运行及独立读回继续验证。没有伪造Plan/ACK；prefix测量不证明KV tensor或attention消费相等 |

## MOD 群体与深审

旧24个MOD只是冻结子群。扩展发现清单包含101个numeric-ID记录、100个固定来源读取，其中识别49个声明package/provider仓边界：46个package、3个provider，33公开、16受限；21与旧24重合，28在旧24之外。它们不是49个独立算法，也不是49个已测兼容案例。

原首批深审8例、16项发现、53个源码摘录保留；新增5项深审覆盖GDN、三种StateAxis边界和请求节流。公开包发布4项，受限原始源码留受控位置。7项源码/聚合候选和8项unknown另列，不以仓库数量替代兼容率分母。参见[公开扩展审计封包](../../results/campaigns/ecpa-osdi/runs/mod-audit-expanded/)。

## 修复后的真实 H2：r6 五组

Qwen2.5-7B-Instruct、910B2×2/TP2、block128、maxlen2048、seq1、eager、无APC；每组输入4和1201 tokens，各输出32 tokens。原请求完整响应预算240秒，Host正常shutdown-timeout5秒，原exporter关闭预算2秒。新规则先于原Popen冻结。**这是单family、单方法、单重复的有限机制证据；不等于正式H2全套、性能或模型质量结果。**

| 组别 | 真实HTTP | 有限作用与关闭证据 |
|---|---|---|
| host-only | 2/2 HTTP200 | 四种实际Host角色公共bootstrap；Host块计数1/10 |
| KVCompress单独 | 2/2 HTTP200 | 原scheduler与双TP交易；长请求semantic1201/physical1024/destination8，实际NPU prefix10→9（8目标+1decode追加），Host完成/回收9 |
| Profiler单独 | 2/2 HTTP200 | 原API/scheduler/worker trace与请求映射、关闭汇总对应 |
| KVCompress→Profiler | 2/2 HTTP200 | 逐进程实际顺序成立，KV有限物理效果与Profiler事件均保留 |
| Profiler→KVCompress | 2/2 HTTP200 | 逆向实际顺序成立，同样保留有限效果 |

三组含Profiler的运行共15份原生shard，逐canonical bytes/hash/count/sequence/clock核对，原close_outcome=drained，有限窗口drop/error/loss=0；12条scheduler事件与原Host/RID/clock一致。独立读取确认198个保留/研究writer/driver epoch均退出，原端口无监听、分配NPU进程表空。

[独立五组结果](../../results/campaigns/ecpa-osdi/runs/h2-r6-drain/independent/five-group-finite-results.json) · [原canonical关闭核对](../../results/campaigns/ecpa-osdi/runs/h2-r6-drain/independent/all-profiler-canonical-close-checks.json) · [独立退出证明](../../results/campaigns/ecpa-osdi/runs/h2-r6-drain/independent/independent-terminal-ownership.json)。原manifest SHA256 `fbda64a2833fac7b473bf7022effbccfd37c2efc79398a6b23d68d7f996573ce`；五组结果SHA256 `158860150f579ec57b0fd3a39165b2a99534f2688ecb94642dd6ea1d95b4f633`。

r6源码：Host `f67ad57c854940a90ddfa82a4a984bb6ce2ff923`，Ascend `153535b32417b3ad8fb10dad2f564ddf4dcab1ef`，KV `2f49051b101adf63db7e9079fee276451e7a5678`，Profiler `dab26bc16a44486ab0dc1b4f69e80c01b8c3cc06`，Manager `05357d6a9c84399785cb47d1d2a1ac5cda10f181`。官方wheel构建和RECORD/安装字节绑定保留；不能因为之后main合并就追补原实验资格。

## 三方法对照与适配成本

新环境使用上述四个Host/Ascend/KV/Profiler提交，以及Manager `c86e48d4ba8d596c42720deb41c3329a91e4b478`。五源官方wheel的5134个实际安装文件已由root在新启动前重hash。所选Host、Profiler、Manager提交均已核实为各自merged main祖先。首native块已完成五组、10次真实HTTP200；[最终原始快照](../../results/campaigns/ecpa-osdi/runs/h2-r7-native-repeat1-final/)与[先前进行中快照](../../results/campaigns/ecpa-osdi/runs/h2-r7-native-repeat1/)分别保留，不覆盖原文件。完整45次仍未完成。

新native首块最终独立核对已完成：五组10次HTTP200，640次真实neutral读回的双rank/Host7/kernel/RAW/hashchain及CPU/NPU prefix一致；三组KV均10→9，原交易与双TP提交对应。15原Profiler shard逐canonical bytes/hash/count/clock/drained核对、12事件与Host多重集严格一一对应，有限窗口reported drops/failures=0。193个实际保留epoch独立确认退出，原30101–30105无LISTEN，两次fresh NPU进程表空。[最终有限报告](../../results/campaigns/ecpa-osdi/runs/h2-r7-independent-final/final-finite-summary.json)（manifest SHA `52d5e66647cae81605bc2d87da72da7d246d0e4569e537efadcca8999bb9c0a7`）；[先前阶段unknown快照](../../results/campaigns/ecpa-osdi/runs/h2-r7-neutral-reader/)保持原样。独立reader在Popen及首批结果可见后实现，heldout=false，未消费attempt/outcome verdict作为oracle。这只支持native repeat1有限谓词，不等于全45完成、认证ACK或质量/性能结论。

固定设计为native官方入口、expert-manual、ECPA各3次独立启动块，每块五组；方法顺序采用Latin排列。最多45次产品启动仍仅1个pair family，不能记为45个独立案例，也不是heldout。新绑定规则SHA256 `f044c2614dfa4d4c42f06ff19787f93d3f658da396cc955d2137f7c5c1990406`。原生/手工使用官方direct KV输入；native Profiler走官方launcher，manual走Host入口；ECPA走Manager配置/Plan启动，不复制ECPA resolved env冒充native。

公共order adapter、研究observer与NPU同步读回对三法共同披露。原首块studyloader318物理行、新生产drain+51/−1仅为代码规模，不能当作人工适配时间。[三方法接线成本表及9处源码依据](../../results/campaigns/ecpa-osdi/runs/three-method-adaptation-cost/README.md)已单独同步。历史人时unknown；后续逐项记录真实配置步骤、构建、安装、重试及失败。输出指纹只检查同组同算法的有限wrapper透明性，先列方法内重复差异；不把压缩/不压缩文本差异当质量评分，不把单次不同输出自动归因ECPA。

## 保留的失败和未知

[开发r1–r5原件封包](../../results/campaigns/ecpa-osdi/runs/h2-development-r1-r5/)保留全部选定stdout/stderr、Popen/epoch、HTTP、配置与测量；仅排除cache/生成二进制。

- r1：生成vllm脚本的spawn递归；后续改用官方Host模块CLI，新运行留独立身份。
- r2：物理卡与容器逻辑可见编号不一致；本环境物理0/3对应逻辑0/1。
- r3：KV单组真实请求成功，其余组在Host启动前因TIME_WAIT bind失败；属于启动设施问题。
- r4：其余四组真实HTTP成功，但Profiler scheduler关闭汇总及host-only observer缺失，完整作用判定unknown。
- r5：新公共bootstrap仅验证host-only，不能补写r4。
- r6：独立新运行得到上述有限支持，仍未建立三方法/重复/质量/性能或多family兼容结论。

这些失败不直接归为MOD算法冲突；修复不覆盖旧数据。新runner另修TIME_WAIT判定为真实连接拒绝，保留旧端口失败。native/manual缺认证Plan也不自动判测量无效；实际测量缺失/矛盾分别记unknown/失败。

## 原 H1–H4 与投稿判断

| 验收项 | 当前可引用事实 | 仍缺什么 |
|---|---|---|
| H1 / #59 | 原r5表和聚合保留9次validator-approved starts；partial-worker-coverage中ECPA 3/3在coverage0.5报告false-effective，原假设已被反例证伪 | 不能用clean-wheel双卡功能预检或新的H2覆盖原反例；当前修复后完整原生资格和主张需重新证明 |
| ExposureGate / #60 | 原authority/成员绑定实现与缺口见issue快照及总账 | 真实authority所有权与完整process membership验收仍未完成 |
| H2 / #63 | 原独立计分n=4保留；r6有真实有限五组支持；扩展MOD审计及PP矛盾源级反例已交付 | 三方法×3重复、多family/heldout、适配成本与完整正式资格未闭合；旧0.95门槛未改 |
| H3 / #61 | 原25cells/225starts矩阵未完成；当前observer九启动计划中4次进入真实故障且均objective failure，第5次在故障前被拒，完整九次未交 | 0 complete formal results；失败与未启动不能删除或当通过 |
| H4 / #62 | 历史lifecycle 9/9、2448 HTTP200仅保留原范围；上次自动H4在Host前source-byte binding失败 | clean matched performance 0/36，不能用研究探针运行或历史吞吐替代 |
| #64 / #65 | 真实接口主线、新baseline和匿名稿件工作保留；[PR258](https://github.com/vLLM-HUST/extension-manager/pull/258)仍开放 | novelty、外部有效性、匿名artifact和全部投稿门槛仍未完成 |

**整体NO-GO：目前不能宣称OSDI投稿实验已完成。** 各issue正文可能是较旧快照，当前优先读#66头部，再沿原件追溯；本仓保留同步时读取的#59–#66正文，不把旧勾选项当作新native资格。Ascend [PR #50](https://github.com/vLLM-HUST/vllm-ascend-hust/pull/50)仍开放，未被描述为已合并。

## 与本项目成本阶梯的关系

本研究用Qwen2.5-7B机制请求验证接口/生命周期/物理prefix；现有引擎成本阶梯以Qwen3.5-35B及各冻结数据集/质量预算为依据。两者模型、配置、费用和评分边界不同，**本轮不新增成本下降台阶、不填写收益百分比、不复用其他线程的质量成绩**。MOD共启、有限效果、完整任务质量和稳定净成本分别验收。

**本仓只同步相关数据、结论与证据，不维护论文稿件。** 论文源稿、PDF和Tectonic编译材料统一维护在ECPA的 [extension-manager PR258](https://github.com/vLLM-HUST/extension-manager/pull/258)。该稿仍Draft/open，正文12页、总14页不代表投稿已就绪。本仓[历史结果封包](../../results/campaigns/ecpa-osdi/runs/historical-result-evidence/)只保留H1/H2实验表格、聚合、MOD源码依据及研究结论，已排除论文TeX/Bib/PDF和构建文件。

## 下一步

1. 完成本次单family三方法、三重复和两种实际顺序；失败和unknown保留原分母，及时释放已完成推理进程显存。
2. 扩展代表性共享hook/状态/拓扑冲突组合，以独立raw oracle验证ECPA准入和运行时效果，记录显式adapter与共同工具成本。
3. 在本研究结论边界内更新稿件；继续原H1–H4、ExposureGate、匿名artifact和go/no-go，不因单个正例提前授予投稿资格。
