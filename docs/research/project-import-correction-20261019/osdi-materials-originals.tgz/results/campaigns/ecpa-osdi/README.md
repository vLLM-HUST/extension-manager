# ECPA OSDI 研究 campaign

[研究进展与限制](../../../docs/research/ecpa-osdi.md) · [原执行总账](https://github.com/vLLM-HUST/extension-manager/issues/66)

本目录导入当前可核验结果，历史来源保持原字节、原资格和原unknown。更新时间见 `import-provenance.json`；运行中的快照带各自捕获时间，不等于最终结果。

| 目录 | 内容 |
|---|---|
| `ledger/` | #59–#66正文及Manager/Host/Profiler/Ascend PR的API状态快照 |
| `runs/h2-r6-drain/` | 五组、10真实HTTP、15原drained shard，独立有限结果/关闭/清理证明及原件archive |
| `runs/h2-development-r1-r5/` | 已有失败、成功与unknown；保留stdout/stderr、HTTP、epoch和配置 |
| `runs/h2-r7-native-repeat1/` | 首native块先前进行中快照，原unknown/in-progress保留 |
| `runs/h2-r7-native-repeat1-final/` | 同一原块五组10真实HTTP终态快照，仍非全45完成 |
| `runs/h3-h4-retained-failures/` | H3/H4原始启动/准入失败与终态、受控原件逐文件inventory |
| `runs/three-method-adaptation-cost/` | 三方法接线成本、9处固定源码依据，未知人时/开销不填0 |
| `runs/h2-r7-neutral-reader/` | 新neutral原读回及Profiler独立阶段核对，明确事后reader/非heldout |
| `runs/h2-r7-independent-final/` | 五组最终独立有限核对：640读回、15原drained shards、193epochs与端口/NPU清理 |
| `runs/mod-audit-expanded/` | 公开MOD扩展群体与深审，受限原始源码不入库 |
| `runs/historical-result-evidence/` | 固定来源的H1/H2结果、MOD证据及研究结论；不含论文稿件 |
| `runs/fixed-inputs-and-source/` | 固定五源、安装字节证明、规则、研究runner、token输入与配置 |
| `controlled-storage.json` | 未复制的wheel、校准及受限/历史runtime原件受控存储索引；明确当前持久性限制 |

`*.tgz`保留原始载荷；每个archive有逐文件SHA256、原路径、字节数和archive SHA。原文中的绝对路径是原始来源，不表示远端下载地址；用archive manifest映射定位。原始nonce/epoch只用于研究关联，不是平台或GitHub访问凭据。

复核时先验证顶层 `files.sha256.json`，再验证各archive SHA及成员SHA；公开报告中的统计仍需对照raw/source语义，清单自身不是兼容oracle。历史H3/H4以ledger原件及受控inventory/固定源链接追溯，已同步选定原始失败/终态；尚未把所有大体积raw或capability凭据复制到本仓；不会把本地存在说成远端已备份。

本campaign不更改本项目Qwen3.5成本阶梯，未授予性能、质量或正式投稿资格；总判断NO-GO。

本地离线完整性复核：`python -B results/campaigns/ecpa-osdi/verify.py`（从仓库根执行，不加载模型）。

论文发布边界：本仓不维护TeX/Bib/PDF或论文构建副本，稿件统一在[ECPA PR258](https://github.com/vLLM-HUST/extension-manager/pull/258)。本次纠正移除了误放的稿件副本，实验原件和旧失败/unknown判定不变。
